"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContactService = void 0;
const contact_model_1 = __importDefault(require("../models/contact.model"));
class ContactService {
    async getAll() {
        return contact_model_1.default.find().exec();
    }
    async getById(id) {
        const contact = await contact_model_1.default.findById(id).exec();
        if (!contact) {
            throw new Error(`Contact with id: ${id} not found`);
        }
        return contact;
    }
    async create(newContact) {
        const contact = new contact_model_1.default(newContact);
        return contact.save();
    }
    async updateArchiveStatus(payload) {
        const { id, archiveStatus } = payload;
        const contact = await contact_model_1.default.findById(id).exec();
        if (!contact) {
            throw new Error(`Contact with id: ${id} not found`);
        }
        contact.actions.archive = archiveStatus;
        try {
            return await contact.save();
        }
        catch (error) {
            console.error('Error saving contact:', error);
            throw new Error('Failed to save updated contact.');
        }
    }
    async delete(id) {
        const result = await contact_model_1.default.findByIdAndDelete(id).exec();
        return result !== null;
    }
}
exports.ContactService = ContactService;
//# sourceMappingURL=contactService.js.map