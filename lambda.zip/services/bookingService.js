"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BookingService = void 0;
const booking_model_1 = __importDefault(require("../models/booking.model"));
class BookingService {
    async getAll() {
        return booking_model_1.default.find().exec();
    }
    async getById(id) {
        const booking = await booking_model_1.default.findById(id).exec();
        if (!booking) {
            throw new Error(`User with id: ${id} not found`);
        }
        return booking;
    }
    async create(newBooking) {
        const booking = new booking_model_1.default(newBooking);
        return booking.save();
    }
    async update(id, updatedBooking) {
        const booking = await booking_model_1.default.findByIdAndUpdate(id, updatedBooking, { new: true }).exec();
        if (!booking) {
            throw new Error(`Room with id: ${id} not found`);
        }
        return booking;
    }
    async delete(id) {
        const result = await booking_model_1.default.findByIdAndDelete(id).exec();
        return result !== null;
    }
}
exports.BookingService = BookingService;
//# sourceMappingURL=bookingService.js.map