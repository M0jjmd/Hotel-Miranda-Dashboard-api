"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RoomService = void 0;
const room_model_1 = __importDefault(require("../models/room.model"));
class RoomService {
    async getAll() {
        return room_model_1.default.find().exec();
    }
    async getById(id) {
        const room = await room_model_1.default.findById(id).exec();
        if (!room) {
            throw new Error(`User with id: ${id} not found`);
        }
        return room;
    }
    async create(newUser) {
        const room = new room_model_1.default(newUser);
        return room.save();
    }
    async update(id, updatedRoom) {
        const room = await room_model_1.default.findByIdAndUpdate(id, updatedRoom, { new: true }).exec();
        if (!room) {
            throw new Error(`Room with id: ${id} not found`);
        }
        return room;
    }
    async delete(id) {
        const result = await room_model_1.default.findByIdAndDelete(id).exec();
        return result !== null;
    }
}
exports.RoomService = RoomService;
//# sourceMappingURL=roomService.js.map