"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const user_model_1 = __importDefault(require("../models/user.model"));
class UserService {
    async getAll() {
        return user_model_1.default.find().exec();
    }
    async getById(id) {
        const user = await user_model_1.default.findById(id).exec();
        if (!user) {
            throw new Error(`User with id: ${id} not found`);
        }
        return user;
    }
    async create(newUser) {
        const user = new user_model_1.default(newUser);
        return user.save();
    }
    async update(id, updatedUser) {
        const user = await user_model_1.default.findByIdAndUpdate(id, updatedUser, { new: true }).exec();
        if (!user) {
            throw new Error(`User with id: ${id} not found`);
        }
        return user;
    }
    async delete(id) {
        const result = await user_model_1.default.findByIdAndDelete(id).exec();
        return result !== null;
    }
}
exports.UserService = UserService;
//# sourceMappingURL=userService.js.map