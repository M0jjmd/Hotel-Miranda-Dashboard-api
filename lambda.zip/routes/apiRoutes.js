"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const loginController_1 = require("../controllers/loginController");
const userController_1 = require("../controllers/userController");
const contactController_1 = require("../controllers/contactController");
const roomController_1 = require("../controllers/roomController");
const bookingController_1 = require("../controllers/bookingController");
const authMiddleware_1 = require("../middleware/authMiddleware");
const router = (0, express_1.Router)();
router.post('/login', loginController_1.loginController);
router.use('/users', authMiddleware_1.authenticateTokenMiddleware, userController_1.usersController);
router.use('/contacts', authMiddleware_1.authenticateTokenMiddleware, contactController_1.contactsController);
router.use('/rooms', authMiddleware_1.authenticateTokenMiddleware, roomController_1.roomsController);
router.use('/bookings', authMiddleware_1.authenticateTokenMiddleware, bookingController_1.bookingsController);
const errorHandler = (err, req, res, next) => {
    console.error(err);
    res.status(err.status || 500).json({ message: err.message || 'Internal server error' });
};
router.use(errorHandler);
exports.default = router;
//# sourceMappingURL=apiRoutes.js.map