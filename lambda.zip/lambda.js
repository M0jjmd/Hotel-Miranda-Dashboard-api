"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const dotenv_1 = __importDefault(require("dotenv"));
const app_1 = __importDefault(require("./app"));
const db_1 = __importDefault(require("./config/db"));
const serverless_http_1 = __importDefault(require("serverless-http"));
dotenv_1.default.config();
(0, db_1.default)()
    .then(() => {
    console.log('Connected to MongoDB');
})
    .catch((err) => {
    console.error('Error connecting to MongoDB:', err);
    process.exit(1);
});
exports.handler = (0, serverless_http_1.default)(app_1.default);
//# sourceMappingURL=lambda.js.map