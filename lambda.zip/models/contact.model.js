"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const ContactSchema = new mongoose_1.Schema({
    date: { type: Date, required: true },
    customer: {
        userId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User', required: true },
        name: { type: String, required: true },
        email: { type: String, required: true },
        phone: { type: String, required: true }
    },
    subject: { type: String, required: true },
    comment: { type: String, required: true },
    actions: {
        archive: { type: Boolean, required: true }
    }
});
const Contact = (0, mongoose_1.model)('Contact', ContactSchema);
exports.default = Contact;
//# sourceMappingURL=contact.model.js.map