"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const RoomSchema = new mongoose_1.Schema({
    Photo: { type: String, required: true },
    RoomNumber: { type: Number, required: true },
    BedType: { type: String, required: true },
    Facilities: { type: [String], required: true },
    Rate: { type: Number, required: true },
    OfferPrice: { type: Number, required: true },
    Status: { type: String, required: true },
});
const Room = (0, mongoose_1.model)('Room', RoomSchema);
exports.default = Room;
//# sourceMappingURL=room.model.js.map