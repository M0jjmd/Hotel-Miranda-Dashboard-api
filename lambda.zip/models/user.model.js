"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const UserSchema = new mongoose_1.Schema({
    username: { type: String, required: true },
    FullName: { type: String, required: true },
    password: { type: String },
    Email: { type: String, required: true, unique: true },
    Photo: { type: String, required: true },
    EntryDate: { type: Date, required: true },
    PositionDescription: { type: String, required: true },
    Phone: { type: String, required: true },
    State: { type: String, required: true },
    position: { type: String, required: true },
});
const User = (0, mongoose_1.model)('User', UserSchema);
exports.default = User;
//# sourceMappingURL=user.model.js.map