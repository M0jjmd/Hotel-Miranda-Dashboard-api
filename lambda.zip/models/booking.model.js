"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const BookingSchema = new mongoose_1.Schema({
    Guest: {
        UserId: { type: String, required: true },
        RoomId: { type: String, required: true }
    },
    OrderDate: { type: Date, required: true },
    CheckIn: { type: Date, required: true },
    CheckOut: { type: Date, required: true },
    SpecialRequest: { type: String, required: true },
    RoomType: {
        Type: { type: String, required: true },
        RoomNumber: { type: String, required: true }
    },
    Status: { type: String, required: true },
});
const Booking = (0, mongoose_1.model)('Booking', BookingSchema);
exports.default = Booking;
//# sourceMappingURL=booking.model.js.map