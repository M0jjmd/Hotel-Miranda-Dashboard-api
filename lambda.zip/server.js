"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_1 = __importDefault(require("dotenv"));
const app_1 = __importDefault(require("./app"));
const db_1 = __importDefault(require("./config/db"));
dotenv_1.default.config();
(0, db_1.default)()
    .then(() => {
    if (process.env.NODE_ENV !== 'lambda') {
        const port = process.env.PORT || 8080;
        app_1.default.listen(port, () => {
            console.log(`Server running at http://localhost:${port}`);
        });
    }
    else {
        console.log('Lambda function initialized');
    }
})
    .catch((err) => {
    console.error('Error connecting to MongoDB:', err);
    process.exit(1);
});
//# sourceMappingURL=server.js.map