"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.roomsController = void 0;
const express_1 = require("express");
const roomService_1 = require("../services/roomService");
exports.roomsController = (0, express_1.Router)();
exports.roomsController.get("", async (req, res) => {
    const roomService = new roomService_1.RoomService();
    try {
        const rooms = await roomService.getAll();
        return res.status(200).send(rooms);
    }
    catch (error) {
        console.error('Error fetching rooms:', error);
        return res.status(500).send({ error: 'Error fetching rooms' });
    }
});
exports.roomsController.get("/:id", async (req, res) => {
    const userService = new roomService_1.RoomService();
    try {
        const room = await userService.getById(req.params.id);
        return res.status(200).send(room);
    }
    catch (error) {
        console.error('Error fetching room:', error);
        return res.status(500).send({ error: 'Error fetching room' });
    }
});
exports.roomsController.post("", async (req, res) => {
    const roomService = new roomService_1.RoomService();
    const newRoom = req.body;
    try {
        const createdRoom = await roomService.create(newRoom);
        return res.status(201).send(createdRoom);
    }
    catch (error) {
        return res.status(500).send({ error: "Error creating the room" + error });
    }
});
exports.roomsController.put("/:id", async (req, res) => {
    const roomService = new roomService_1.RoomService();
    const roomId = req.params.id;
    const updatedRoomData = req.body;
    try {
        const updatedRoom = await roomService.update(roomId, updatedRoomData);
        if (updatedRoom) {
            return res.status(200).send(updatedRoom);
        }
        else {
            return res.status(404).send({ message: "Room not found" });
        }
    }
    catch (error) {
        return res.status(500).send({ error: "Error updating the room" });
    }
});
exports.roomsController.delete("/:id", async (req, res) => {
    const roomService = new roomService_1.RoomService();
    const roomId = req.params.id;
    try {
        const successfulDelete = await roomService.delete(roomId);
        if (successfulDelete) {
            return res.status(200).send({ message: "Room deleted successfully" });
        }
        else {
            return res.status(404).send({ message: "Room not found" });
        }
    }
    catch (error) {
        return res.status(500).send({ error: "Error deleting the room" });
    }
});
//# sourceMappingURL=roomController.js.map