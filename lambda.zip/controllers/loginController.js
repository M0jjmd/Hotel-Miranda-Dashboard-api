"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.loginController = void 0;
const dotenv_1 = __importDefault(require("dotenv"));
const express_1 = __importDefault(require("express"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const bcrypt_1 = __importDefault(require("bcrypt"));
const user_model_1 = __importDefault(require("../models/user.model"));
dotenv_1.default.config();
exports.loginController = express_1.default.Router();
exports.loginController.post('/login', async (req, res) => {
    const SECRET_KEY = process.env.SECRET_KEY || 'fallback_secret_key';
    const { username, password } = req.body;
    if (!username || !password) {
        return res.status(400).json({ message: 'Username and password are required' });
    }
    try {
        const user = await user_model_1.default.findOne({ username });
        if (!user) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }
        const isMatch = await bcrypt_1.default.compare(password, user.password || '');
        if (!isMatch) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }
        const payload = { username: user.username, id: user._id };
        const token = jsonwebtoken_1.default.sign(payload, SECRET_KEY, { expiresIn: '1h' });
        return res.status(200).json({
            token,
            name: user.FullName,
            email: user.Email,
            id: user._id,
        });
    }
    catch (error) {
        console.error('Error during login:', error);
        return res.status(500).json({ message: 'Internal server error' });
    }
});
//# sourceMappingURL=loginController.js.map