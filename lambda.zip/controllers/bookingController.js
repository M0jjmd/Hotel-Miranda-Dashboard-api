"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.bookingsController = void 0;
const express_1 = require("express");
const bookingService_1 = require("../services/bookingService");
exports.bookingsController = (0, express_1.Router)();
exports.bookingsController.get("", async (req, res) => {
    const bookingService = new bookingService_1.BookingService();
    try {
        const bookings = await bookingService.getAll();
        return res.status(200).send(bookings);
    }
    catch (error) {
        console.error('Error fetching bookings:', error);
        return res.status(500).send({ error: 'Error fetching bookings' });
    }
});
exports.bookingsController.get("/:id", async (req, res) => {
    const bookingService = new bookingService_1.BookingService();
    try {
        const booking = await bookingService.getById(req.params.id);
        return res.status(200).send(booking);
    }
    catch (error) {
        console.error('Error fetching booking:', error);
        return res.status(500).send({ error: 'Error fetching booking' });
    }
});
exports.bookingsController.post("", async (req, res) => {
    const bookingService = new bookingService_1.BookingService();
    const newBooking = req.body;
    try {
        const createdBooking = await bookingService.create(newBooking);
        return res.status(201).send(createdBooking);
    }
    catch (error) {
        return res.status(500).send({ error: "Error creating the booking" + error });
    }
});
exports.bookingsController.put("/:id", async (req, res) => {
    const bookingService = new bookingService_1.BookingService();
    const bookingId = req.params.id;
    const updatedBookingData = req.body;
    try {
        const updatedBooking = await bookingService.update(bookingId, updatedBookingData);
        if (updatedBooking) {
            return res.status(200).send(updatedBooking);
        }
        else {
            return res.status(404).send({ message: "Booking not found" });
        }
    }
    catch (error) {
        return res.status(500).send({ error: "Error updating the booking" });
    }
});
exports.bookingsController.delete("/:id", async (req, res) => {
    const bookingService = new bookingService_1.BookingService();
    const bookingId = req.params.id;
    try {
        const successfulDelete = await bookingService.delete(bookingId);
        if (successfulDelete) {
            return res.status(200).send({ message: "Booking deleted successfully" });
        }
        else {
            return res.status(404).send({ message: "Booking not found" });
        }
    }
    catch (error) {
        return res.status(500).send({ error: "Error deleting the booking" });
    }
});
//# sourceMappingURL=bookingController.js.map