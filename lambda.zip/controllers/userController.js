"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.usersController = void 0;
const express_1 = require("express");
const userService_1 = require("../services/userService");
const bcrypt_1 = __importDefault(require("bcrypt"));
exports.usersController = (0, express_1.Router)();
exports.usersController.get("", async (req, res) => {
    const userService = new userService_1.UserService();
    try {
        const users = await userService.getAll();
        return res.status(200).send(users);
    }
    catch (error) {
        console.error('Error fetching users:', error);
        return res.status(500).send({ error: 'Error fetching users' });
    }
});
exports.usersController.get("/:id", async (req, res) => {
    const userService = new userService_1.UserService();
    try {
        const user = await userService.getById(req.params.id);
        return res.status(200).send(user);
    }
    catch (error) {
        console.error('Error fetching user:', error);
        return res.status(500).send({ error: 'Error fetching user' });
    }
});
exports.usersController.post("", async (req, res) => {
    const userService = new userService_1.UserService();
    const newUser = req.body;
    if (newUser.password) {
        try {
            const saltRounds = 10;
            const hashedPassword = await bcrypt_1.default.hash(newUser.password, saltRounds);
            newUser.password = hashedPassword;
        }
        catch (error) {
            return res.status(500).send({ error: "Error hashing the password" });
        }
        try {
            const createdUser = await userService.create(newUser);
            return res.status(201).send(createdUser);
        }
        catch (error) {
            return res.status(500).send({ error: "Error creating the user" });
        }
    }
});
exports.usersController.put("/:id", async (req, res) => {
    const userService = new userService_1.UserService();
    const userId = req.params.id;
    const updatedUserData = req.body;
    try {
        const updatedUser = await userService.update(userId, updatedUserData);
        if (updatedUser) {
            return res.status(200).send(updatedUser);
        }
        else {
            return res.status(404).send({ message: "User not found" });
        }
    }
    catch (error) {
        return res.status(500).send({ error: "Error updating the user" });
    }
});
exports.usersController.delete("/:id", async (req, res) => {
    const userService = new userService_1.UserService();
    const userId = req.params.id;
    try {
        const successfulDelete = await userService.delete(userId);
        if (successfulDelete) {
            return res.status(200).send({ message: "User deleted successfully" });
        }
        else {
            return res.status(404).send({ message: "User not found" });
        }
    }
    catch (error) {
        return res.status(500).send({ error: "Error deleting the user" });
    }
});
//# sourceMappingURL=userController.js.map