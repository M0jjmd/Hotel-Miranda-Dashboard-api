"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.contactsController = void 0;
const express_1 = require("express");
const contactService_1 = require("../services/contactService");
exports.contactsController = (0, express_1.Router)();
exports.contactsController.get("", async (req, res) => {
    const contactService = new contactService_1.ContactService();
    try {
        const contacts = await contactService.getAll();
        return res.status(200).send(contacts);
    }
    catch (error) {
        console.error('Error fetching contacts:', error);
        return res.status(500).send({ error: 'Error fetching contacts' });
    }
});
exports.contactsController.get("/:id", async (req, res) => {
    const contactService = new contactService_1.ContactService();
    try {
        const contact = await contactService.getById(req.params.id);
        return res.status(200).send(contact);
    }
    catch (error) {
        console.error('Error fetching contact:', error);
        return res.status(500).send({ error: 'Error fetching contact' });
    }
});
exports.contactsController.post("", async (req, res) => {
    const contactService = new contactService_1.ContactService();
    const newContact = req.body;
    try {
        const createdContact = await contactService.create(newContact);
        return res.status(201).send(createdContact);
    }
    catch (error) {
        return res.status(500).send({ error: "Error creating the contact" });
    }
});
exports.contactsController.patch("/:id/archive-status", async (req, res) => {
    const contactService = new contactService_1.ContactService();
    const payload = {
        id: req.params.id,
        archiveStatus: req.body.actions.archive
    };
    try {
        const updatedContact = await contactService.updateArchiveStatus(payload);
        if (updatedContact) {
            return res.status(200).send(updatedContact);
        }
        else {
            return res.status(404).send({ message: "Contact not found" });
        }
    }
    catch (error) {
        console.error('Error updating archive status:', error);
        return res.status(500).send({ error: "Error updating archive status" });
    }
});
exports.contactsController.delete("/:id", async (req, res) => {
    const contactService = new contactService_1.ContactService();
    const contactId = req.params.id;
    try {
        const successfulDelete = await contactService.delete(contactId);
        if (successfulDelete) {
            return res.status(200).send({ message: "Contact deleted successfully" });
        }
        else {
            return res.status(404).send({ message: "Contact not found" });
        }
    }
    catch (error) {
        return res.status(500).send({ error: "Error deleting the contact" });
    }
});
//# sourceMappingURL=contactController.js.map