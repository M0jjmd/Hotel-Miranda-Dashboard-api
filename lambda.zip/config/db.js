"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_1 = __importDefault(require("dotenv"));
const mongoose_1 = __importDefault(require("mongoose"));
dotenv_1.default.config();
const url = process.env.SERVER_URL;
console.log(url + "console log de la conexion db");
const connectDB = async () => {
    if (!url) {
        console.error('Server URL is not defined');
        return;
    }
    try {
        await mongoose_1.default.connect(url);
        console.log('MongoDB Connected');
    }
    catch (error) {
        console.error('Error connecting to MongoDB:', error);
    }
};
exports.default = connectDB;
//# sourceMappingURL=db.js.map